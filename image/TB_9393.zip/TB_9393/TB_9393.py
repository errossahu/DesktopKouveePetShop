import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *



display = (1400,600)

keys = {
	"kotakkanan": False,
	"kotakkiri": False,
	"kotakmaju": False,
	"kotakmundur": False,
	"lemarimaju": False,
	"lemarimundur": False,
}

def inisialisasi():
	glClearColor(1.0, 1.0, 1.0, 1.0)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
	glViewport(0,0,display[0], display[1])
	glMatrixMode(GL_PROJECTION)
	glLoadIdentity()
	gluPerspective(45, (display[0]/display[1]), 0.1, 100.0)
	glMatrixMode(GL_MODELVIEW)

	
def initCahaya():
   ambient = [0.5, 0.5, 0.5, 1.0]
   diffuse = [1.0, 0, 1.0, 1.0]
   specular = [1.0, 1.0, 1.0, 1.0]
   position = [0, 0.5, 0.5, 0.0]

   lma = [0.2, 0.2, 0.2, 1.0]
   lv = [0.0]

   glLightfv(GL_LIGHT0, GL_AMBIENT, ambient)
   glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse)
   glLightfv(GL_LIGHT0, GL_POSITION, position)
   glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lma)
   glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, lv)

   glFrontFace(GL_CW)
   glEnable(GL_LIGHTING)
   glEnable(GL_LIGHT0)
   glEnable(GL_AUTO_NORMAL)
   glEnable(GL_NORMALIZE)
   glEnable(GL_DEPTH_TEST)
   
   global daftarKubus
   daftarKubus = glGenLists(1)
   
   glNewList (daftarKubus, GL_COMPILE)
   kotakWarnaTekstur()
   glEndList ()
   
def loadTextureMeja(ArrayGambar):
    textureSurface = pygame.image.load(ArrayGambar)
    textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
    width = textureSurface.get_width()
    height = textureSurface.get_height()

    glEnable(GL_TEXTURE_2D)
    texid = glGenTextures(1)

    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)

    return texid

def loadTextureKotak_depan() :
	textureSurface = pygame.image.load("resources/Erros_9393.jpg")
	textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
	width = textureSurface.get_width()
	height = textureSurface.get_height()
	
	glEnable(GL_TEXTURE_2D)
	texid = glGenTextures(1)
	
	glBindTexture(GL_TEXTURE_2D, texid)
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
	
	return texid

def loadTextureKotak_atas() :
	textureSurface = pygame.image.load("resources/atas.jpg")
	textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
	width = textureSurface.get_width()
	height = textureSurface.get_height()
	
	glEnable(GL_TEXTURE_2D)
	texid = glGenTextures(1)
	
	glBindTexture(GL_TEXTURE_2D, texid)
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
	
	return texid

def loadTextureKotak_bawah() :
	textureSurface = pygame.image.load("resources/belakang.jpg")
	textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
	width = textureSurface.get_width()
	height = textureSurface.get_height()
	
	glEnable(GL_TEXTURE_2D)
	texid = glGenTextures(1)
	
	glBindTexture(GL_TEXTURE_2D, texid)
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
	
	return texid

def loadTextureKotak_kiri() :
	textureSurface = pygame.image.load("resources/kiri.jpg")
	textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
	width = textureSurface.get_width()
	height = textureSurface.get_height()
	
	glEnable(GL_TEXTURE_2D)
	texid = glGenTextures(1)
	
	glBindTexture(GL_TEXTURE_2D, texid)
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
	
	return texid

def loadTextureKotak_kanan() :
	textureSurface = pygame.image.load("resources/kanan.jpg")
	textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
	width = textureSurface.get_width()
	height = textureSurface.get_height()
	
	glEnable(GL_TEXTURE_2D)
	texid = glGenTextures(1)
	
	glBindTexture(GL_TEXTURE_2D, texid)
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
	
	return texid

def loadTextureKotak_belakang() :
	textureSurface = pygame.image.load("resources/belakang.jpg")
	textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
	width = textureSurface.get_width()
	height = textureSurface.get_height()
	
	glEnable(GL_TEXTURE_2D)
	texid = glGenTextures(1)
	
	glBindTexture(GL_TEXTURE_2D, texid)
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
	
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
	
	return texid
	


def warnaKotak(x, y, ambr, ambg, ambb, difr, difg, difb, specr, specg, specb, shine):
   mat = [0, 0, 0, 0]

   glPushMatrix()
   glTranslatef(x, y, 0.0)
   mat[0] = ambr; mat[1] = ambg; mat[2] = ambb; mat[3] = 1.0
   glMaterialfv(GL_FRONT, GL_AMBIENT, mat)
   
   mat[0] = difr; mat[1] = difg; mat[2] = difb
   glMaterialfv(GL_FRONT, GL_DIFFUSE, mat)
   
   mat[0] = specr; mat[1] = specg; mat[2] = specb
   glMaterialfv(GL_FRONT, GL_SPECULAR, mat)
   
   glMaterialf(GL_FRONT, GL_SHININESS, shine)
   glCallList(daftarKubus)
   glPopMatrix()
   glFlush();

def warnaLemari(ambr, ambg, ambb, difr, difg, difb, specr, specg, specb, shine, nilaiZL) :
	mat = [0, 0, 0, 0]

	glPushMatrix()
	mat[0] = ambr; mat[1] = ambg; mat[2] = ambb; mat[3] = 1.0
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat)

	mat[0] = difr; mat[1] = difg; mat[2] = difb
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat)

	mat[0] = specr; mat[1] = specg; mat[2] = specb
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat)

	glMaterialf(GL_FRONT, GL_SHININESS, shine)
	lemariTekstur(nilaiZL)
	glPopMatrix()
	glFlush();
 
def renderKotak() :
	warnaKotak(0    ,0  ,0.5 ,1.0 , 0.9 , 0.2  , 0.2  , 0.5  , 0.3  , 0.3  , 0.3  , 0.6)
	warnaKotak(0.325,0  ,0.9 ,0.5 , 0.1   , 0.2  , 0.4  , 0    , 0.3  , 0.3  , 0.3  , 0.6)
	warnaKotak(0.650,0  ,1   ,0.4 , 0.8 , 0.2  , 0.2  , 0.2  , 0.3  , 0.3  , 0.3  , 0.6)
	glFlush()

def kerangkaMeja() : 
	glColor3f(1,1,1)
	glPointSize(5)
	
	glBegin(GL_LINE_LOOP) #depan
	glVertex3f(-1,0.05,0.7)
	glVertex3f(0.2,0.05,0.7)
	glVertex3f(0.2,-0.05,0.7)
	glVertex3f(-1,-0.05,0.7)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #belakang
	glVertex3f(-1,0.05,-0.3)
	glVertex3f(0.2,0.05,-0.3)
	glVertex3f(0.2,-0.05,-0.3)
	glVertex3f(-1,-0.05,-0.3)
	glEnd()
		
	glBegin(GL_LINE_LOOP) #kanan
	glVertex3f(0.2,0.05,0.7)
	glVertex3f(0.2,0.05,-0.3)
	glVertex3f(0.2,-0.05,-0.3)
	glVertex3f(0.2,-0.05,0.7)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #kiri
	glVertex3f(-1,0.05,0.7)
	glVertex3f(-1,0.05,-0.3)
	glVertex3f(-1,-0.05,-0.3)
	glVertex3f(-1,-0.05,0.7)
	glEnd()

	
	glBegin(GL_LINE_LOOP) #atas
	glVertex3f(-1,0.05,0.7)
	glVertex3f(-1,0.05,-0.3)
	glVertex3f(0.2,0.05,-0.3)
	glVertex3f(0.2,0.05,0.7)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #bawah
	glVertex3f(-1,-0.05,0.7)
	glVertex3f(-1,-0.05,-0.3)
	glVertex3f(0.2,-0.05,-0.3)
	glVertex3f(0.2,-0.05,0.7)
	glEnd()
	
	glFlush()

def mejaTekstur(ArrayGambar) :
	loadTextureMeja(ArrayGambar)
	glBegin(GL_QUADS) #depan
	glTexCoord2f(0,0); glVertex3f(-1.2,0.05,0.7) 
	glTexCoord2f(1,0); glVertex3f(0.5,0.05,0.7) 
	glTexCoord2f(1,1); glVertex3f(0.5,-0.05,0.7) 
	glTexCoord2f(0,1); glVertex3f(-1.2,-0.05,0.7) 
	glEnd()
		
	glBegin(GL_QUADS) #kanan
	glTexCoord2f(0,0); glVertex3f(0.5,0.05,0.7) 
	glTexCoord2f(1,0); glVertex3f(0.5,0.05,-0.3) 
	glTexCoord2f(1,1); glVertex3f(0.5,-0.05,-0.3) 
	glTexCoord2f(0,1); glVertex3f(0.5,-0.05,0.7) 
	glEnd()
	
	glBegin(GL_QUADS) #kiri
	glTexCoord2f(0,0); glVertex3f(-1.2,0.05,0.7)
	glTexCoord2f(1,0); glVertex3f(-1.2,0.05,-0.3)
	glTexCoord2f(1,1); glVertex3f(-1.2,-0.05,-0.3)
	glTexCoord2f(0,1); glVertex3f(-1.2,-0.05,0.7) 
	glEnd()
	
	glBegin(GL_QUADS) #belakang
	glTexCoord2f(0,0); glVertex3f(-1.2,0.05,-0.3)
	glTexCoord2f(1,0); glVertex3f(0.5,0.05,-0.3) 
	glTexCoord2f(1,1); glVertex3f(0.5,-0.05,-0.3)
	glTexCoord2f(0,1); glVertex3f(-1.2,-0.05,-0.3)
	glEnd()
	
	glBegin(GL_QUADS) #atas
	glTexCoord2f(0,0); glVertex3f(-1.2,0.05,0.7) 
	glTexCoord2f(1,0); glVertex3f(-1.2,0.05,-0.3)
	glTexCoord2f(1,1); glVertex3f(0.5,0.05,-0.3)
	glTexCoord2f(0,1); glVertex3f(0.5,0.05,0.7)
	glEnd()
	
	glBegin(GL_QUADS) #bawah
	glTexCoord2f(0,0); glVertex3f(-1.2,-0.05,0.7)
	glTexCoord2f(1,0); glVertex3f(-1.2,-0.05,-0.3)
	glTexCoord2f(1,1); glVertex3f(0.5,-0.05,-0.3)
	glTexCoord2f(0,1); glVertex3f(0.5,-0.05,0.7)
	glEnd()
	
	glBegin(GL_QUADS) #tiang kiri
	glTexCoord2f(0,0); glVertex3f(-1,-0.05,0.7)
	glTexCoord2f(1,0); glVertex3f(-0.9,-0.05,-0.3)
	glTexCoord2f(1,1); glVertex3f(-0.9,-0.2,-0.3)
	glTexCoord2f(0,1); glVertex3f(-1,-0.2,0.7)
	glEnd()
	
	glBegin(GL_QUADS) #tiang kanan
	glTexCoord2f(0,0); glVertex3f(0.3,0.05,0.7)
	glTexCoord2f(1,0); glVertex3f(0.3,0.05,-0.3)
	glTexCoord2f(1,1); glVertex3f(0.3,-0.2,-0.3)
	glTexCoord2f(0,1); glVertex3f(0.3,-0.2,0.7)
	glEnd()
	
	glFlush()

def kotakGambar(nilaiX, nilaiZ) :
	glPushMatrix()
	
	glBindTexture(GL_TEXTURE_2D, loadTextureKotak_bawah())
	glBegin(GL_QUADS) #bawah
	glTexCoord2f(0,0); glVertex3f(-1+nilaiX,0.1,0.3+nilaiZ) 
	glTexCoord2f(1,0); glVertex3f(-0.8+nilaiX,0.1,0.3+nilaiZ) 
	glTexCoord2f(1,1); glVertex3f(-0.8+nilaiX,0.1,0.1+nilaiZ) 
	glTexCoord2f(0,1); glVertex3f(-1+nilaiX,0.1,0.1+nilaiZ)
	glEnd();
	
	glBindTexture(GL_TEXTURE_2D, loadTextureKotak_kiri())
	glBegin(GL_QUADS) #kiri
	glTexCoord2f(0,0); glVertex3f(-1+nilaiX,0.1,0.3+nilaiZ) 
	glTexCoord2f(1,0); glVertex3f(-1+nilaiX,0.3,0.3+nilaiZ)
	glTexCoord2f(1,1); glVertex3f(-1+nilaiX,0.3,0.1+nilaiZ)
	glTexCoord2f(0,1); glVertex3f(-1+nilaiX,0.1,0.1+nilaiZ)
	glEnd();
	
	glBindTexture(GL_TEXTURE_2D, loadTextureKotak_kanan())
	glBegin(GL_QUADS) #kanan
	glTexCoord2f(0,0); glVertex3f(-0.8+nilaiX,0.1,0.3+nilaiZ)
	glTexCoord2f(1,0); glVertex3f(-0.8+nilaiX,0.3,0.3+nilaiZ)
	glTexCoord2f(1,1); glVertex3f(-0.8+nilaiX,0.3,0.1+nilaiZ)
	glTexCoord2f(0,1); glVertex3f(-0.8+nilaiX,0.1,0.1+nilaiZ)
	glEnd();
	
	glBindTexture(GL_TEXTURE_2D, loadTextureKotak_atas())
	glBegin(GL_QUADS) #atas
	glTexCoord2f(0,0); glVertex3f(-1+nilaiX,0.3,0.3+nilaiZ)
	glTexCoord2f(1,0); glVertex3f(-0.8+nilaiX,0.3,0.3+nilaiZ)
	glTexCoord2f(1,1); glVertex3f(-0.8+nilaiX,0.3,0.1+nilaiZ)
	glTexCoord2f(0,1); glVertex3f(-1+nilaiX,0.3,0.1+nilaiZ)
	glEnd();
	
	glBindTexture(GL_TEXTURE_2D, loadTextureKotak_depan())
	glBegin(GL_QUADS) #depan
	glTexCoord2f(0,0); glVertex3f(-1+nilaiX,0.1,0.3+nilaiZ) 
	glTexCoord2f(1,0); glVertex3f(-0.8+nilaiX,0.1,0.3+nilaiZ) 
	glTexCoord2f(1,1); glVertex3f(-0.8+nilaiX,0.3,0.3+nilaiZ) 
	glTexCoord2f(0,1); glVertex3f(-1+nilaiX,0.3,0.3+nilaiZ)
	glEnd();
	
	glBindTexture(GL_TEXTURE_2D, loadTextureKotak_belakang())
	glBegin(GL_QUADS) #belakang
	glTexCoord2f(0,0); glVertex3f(-1+nilaiX,0.1,0.1+nilaiZ)
	glTexCoord2f(1,0); glVertex3f(-0.8+nilaiX,0.1,0.1+nilaiZ)
	glTexCoord2f(1,1); glVertex3f(-0.8+nilaiX,0.3,0.1+nilaiZ)
	glTexCoord2f(0,1); glVertex3f(-1+nilaiX,0.3,0.1+nilaiZ)
	
	glEnd()
	
	glPopMatrix()
	glFlush();

def kotakWarnaTekstur() :
	glBegin(GL_QUADS)
	glNormal3f(0,0,1)
	glVertex3f(-0.7,0.03,0.3)
	glVertex3f(-0.5,0.03,0.3)
	glVertex3f(-0.5,0.3,0.3)
	glVertex3f(-0.7,0.3,0.3)
	glEnd();
	
	glBegin(GL_QUADS) #belakang
	glNormal3f(0,0,-1)
	glVertex3f(-0.7,0.03,0.1)
	glVertex3f(-0.5,0.03,0.1)
	glVertex3f(-0.5,0.3,0.1)
	glVertex3f(-0.7,0.3,0.1)
	glEnd();
	
	glBegin(GL_QUADS) #atas
	glNormal3f(0,1,0)
	glVertex3f(-0.7,0.3,0.3)
	glVertex3f(-0.5,0.3,0.3)
	glVertex3f(-0.5,0.3,0.1) 
	glVertex3f(-0.7,0.3,0.1)
	glEnd();
	
	glBegin(GL_QUADS) #bawah
	glNormal3f(0,-1,1)
	glVertex3f(-0.7,0.03,0.3)
	glVertex3f(-0.5,0.03,0.3)
	glVertex3f(-0.5,0.03,0.1)
	glVertex3f(-0.7,0.03,0.1)
	glEnd()
	
	glBegin(GL_QUADS) #kiri
	glNormal3f(-1,0,0)
	glVertex3f(-0.7,0.03,0.3)
	glVertex3f(-0.7,0.3,0.3)
	glVertex3f(-0.7,0.3,0.1)
	glVertex3f(-0.7,0.03,0.1)
	glEnd()
	
	glBegin(GL_QUADS) #kanan
	glNormal3f(1,0,0)
	glVertex3f(-0.5,0.03,0.3)
	glVertex3f(-0.5,0.3,0.3)
	glVertex3f(-0.5,0.3,0.1)
	glVertex3f(-0.5,0.03,0.1)
	glEnd();

def kerangkaLemari(nilaiZL) :

	glBegin(GL_QUADS) #depan
	glColor3f(0, 0, 0)
	glVertex3f(-1.5,0.5,0.5+nilaiZL)
	glVertex3f(-2,0.5,0.5+nilaiZL)
	glVertex3f(-2,-0.2,0.5+nilaiZL)
	glVertex3f(-1.5,-0.2,0.5+nilaiZL)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #kiri
	glVertex3f(-1.5,0.5,0.2+nilaiZL)
	glVertex3f(-1.5,0.5,0.5+nilaiZL)
	glVertex3f(-1.5,-7.03,0.5+nilaiZL)
	glVertex3f(-1.5,-7.03,0.2+nilaiZL)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #kanan
	glVertex3f(-2,0.5,0.5+nilaiZL)
	glVertex3f(-2,0.5,0.2+nilaiZL)
	glVertex3f(-2,-0.2,0.2+nilaiZL)
	glVertex3f(-2,-0.2,0.5+nilaiZL)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #belakang
	glVertex3f(-1.5,0.5,0.2+nilaiZL)
	glVertex3f(-2,0.5,0.2+nilaiZL)
	glVertex3f(-2,-0.2,0.2+nilaiZL)
	glVertex3f(-1.5,-0.2,0.2+nilaiZL)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #atas
	glVertex3f(-1.5,0.5,0.5+nilaiZL)
	glVertex3f(-1.5,0.5,0.2+nilaiZL)
	glVertex3f(-2,0.5,0.2+nilaiZL)
	glVertex3f(-2,0.5,0.5+nilaiZL)
	glEnd()
	
	glBegin(GL_LINE_LOOP) #bawah
	glVertex3f(-1.5,-0.2,0.5+nilaiZL)
	glVertex3f(-1.5,-0.2,-0.2+nilaiZL) 
	glVertex3f(-2,-0.2,-0.2+nilaiZL) 
	glVertex3f(-2,-0.2,0.5+nilaiZL)
	glEnd()
	
	glFlush()

def lemariTekstur(nilaiZL) : 
	
	glBegin(GL_QUADS) #depan kanan
	glNormal3f(0,0,1)
	glVertex3f(-1.5,0.5,0.5+nilaiZL)
	glVertex3f(-1.25,0.5,0.6+nilaiZL)
	glVertex3f(-1.25,-0.2,0.6+nilaiZL)
	glVertex3f(-1.5,-0.2,0.5+nilaiZL)
	glEnd()
	
	glBegin(GL_QUADS) #depan kiri
	glNormal3f(0,0,1)
	glVertex3f(-2.0,0.5,0.5+nilaiZL)
	glVertex3f(-2.25,0.5,0.6+nilaiZL)
	glVertex3f(-2.25,-0.2,0.6+nilaiZL)
	glVertex3f(-2.0,-0.2,0.5+nilaiZL)
	glEnd()
	
	
	glBegin(GL_QUADS) #kiri
	glNormal3f(-1,0,0)
	glVertex3f(-1.5,0.5,0.2+nilaiZL)
	glVertex3f(-1.5,0.5,0.5+nilaiZL)
	glVertex3f(-1.5,-0.2,0.5+nilaiZL)
	glVertex3f(-1.5,-0.2,0.2+nilaiZL)
	glEnd()
	
	glBegin(GL_QUADS) #kanan
	glNormal3f(1,0,0)
	glVertex3f(-2,0.5,0.5+nilaiZL)
	glVertex3f(-2,0.5,0.2+nilaiZL) 
	glVertex3f(-2,-0.2,0.2+nilaiZL)
	glVertex3f(-2,-0.2,0.5+nilaiZL) 
	glEnd()
	
	glBegin(GL_QUADS) #belakang
	glNormal3f(0,0,-1)
	glVertex3f(-1.5,0.5,0.2+nilaiZL) 
	glVertex3f(-2,0.5,0.2+nilaiZL) 
	glVertex3f(-2,-0.2,0.2+nilaiZL) 
	glVertex3f(-1.5,-0.2,0.2+nilaiZL) 
	glEnd()
	
	glBegin(GL_QUADS) #atas
	glNormal3f(0,1,0)
	glVertex3f(-1.5,0.5,0.5+nilaiZL)
	glVertex3f(-1.5,0.5,0.2+nilaiZL)
	glVertex3f(-2,0.5,0.2+nilaiZL) 
	glVertex3f(-2,0.5,0.5+nilaiZL) 
	glEnd()
	
	glBegin(GL_QUADS) #bawah
	glNormal3f(0,-1,0)
	glVertex3f(-1.5,-0.2,0.5+nilaiZL)
	glVertex3f(-1.5,-0.2,0.2+nilaiZL) 
	glVertex3f(-2,-0.2,0.2+nilaiZL) 
	glVertex3f(-2,-0.2,0.5+nilaiZL)
	glEnd()
	
    
	glFlush()

def main():
	pygame.init()
	pygame.display.set_mode(display, DOUBLEBUF|OPENGL)
	inisialisasi()
	initCahaya()
	glTranslatef(0,0,-3)
	glRotatef(30,1,0,0)
	
	gambar = ["teksturbesi.jpg" , "teksturkayu.jpg","teksturplastik.jpg"]
	i=0
	nilaiZ = 0;
	nilaiX = 0;
	nilaiZL = 0;

	while True :
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				quit()

			if event.type == pygame.KEYDOWN :
				if event.key == K_p :
					if i<2 :
						i=i+1
					elif i>=2 :
						i=0
				elif event.key == K_UP :
					keys["kotakmaju"] = True
				elif event.key == K_DOWN :
					keys["kotakmundur"] = True
				elif event.key == K_LEFT :
					keys["kotakkiri"] = True
				elif event.key == K_RIGHT :
					keys["kotakkanan"] = True
				elif event.key == K_d :
					keys["lemarimaju"] = True
				elif event.key == K_b :
					keys["lemarimundur"] = True
					
					
			if event.type == pygame.KEYUP :
				if event.key == K_p :
					print(" ")
				elif event.key == K_UP :
					keys["kotakmaju"] = False
				elif event.key == K_DOWN :
					keys["kotakmundur"] = False
				elif event.key == K_LEFT :
					keys["kotakkiri"] = False
				elif event.key == K_RIGHT :
					keys["kotakkanan"] = False
				elif event.key == K_d :
					keys["lemarimaju"] = False
				elif event.key == K_b :
					keys["lemarimundur"] = False
			
		if keys["kotakmaju"] :
			nilaiZ -= 0.01
		elif keys["kotakmundur"] : 
			nilaiZ += 0.01
		elif keys["kotakkiri"] : 
			nilaiX -= 0.01
		elif keys["kotakkanan"] : 
			nilaiX += 0.01
		elif keys["lemarimaju"] : 
			nilaiZL -= 0.05
		elif keys["lemarimundur"] : 
			nilaiZL += 0.05
		
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
		
		renderKotak()
		glEnable( GL_TEXTURE_2D )
		glEnable( GL_DEPTH_TEST )
		kotakGambar(nilaiX,nilaiZ)
		
		glPushMatrix()
		glScalef(1, 2, 1)
		glTranslatef(0, 0, 0)
		mejaTekstur(gambar[i])
		glPopMatrix()
		
		glDisable( GL_TEXTURE_2D )
		
		warnaLemari(0.15 , 0.75 , 0 , 0.15 , 0.75 , 0 , 0.8, 0.1, 0.3 , 0.6 , nilaiZL)
		
		pygame.display.flip()
		pygame.time.wait(10)
main()

